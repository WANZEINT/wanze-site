
export default function CN() {
  return <div style={{padding:40}}>中文版本 - 万泽国际</div>;
}
