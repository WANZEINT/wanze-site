
export default function EN() {
  return <div style={{padding:40}}>English Version - WANZE INTERNATIONAL</div>;
}
