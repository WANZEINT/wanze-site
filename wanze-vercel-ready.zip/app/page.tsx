
import Hero from "../components/Hero";
import Products from "../components/Products";
import OEM from "../components/OEM";
import Contact from "../components/Contact";

export default function Home() {
  return (
    <main>
      <Hero />
      <Products />
      <OEM />
      <Contact />
    </main>
  );
}
