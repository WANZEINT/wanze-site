
"use client";
import { useState } from "react";

export default function Contact(){
  const [data,setData] = useState({});

  const send = async ()=>{
    await fetch("/api/lead",{method:"POST",body:JSON.stringify(data)});
    alert("Sent");
  };

  return (
    <section style={{padding:40}}>
      <h2 style={{color:"#d4af37"}}>Contact</h2>

      <input placeholder="Name" onChange={e=>setData({...data,name:e.target.value})}/>
      <br/>
      <input placeholder="Email" onChange={e=>setData({...data,email:e.target.value})}/>
      <br/>
      <textarea placeholder="Message" onChange={e=>setData({...data,message:e.target.value})}/>
      <br/>
      <button onClick={send}>Send</button>
    </section>
  );
}
