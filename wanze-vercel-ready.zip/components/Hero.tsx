
export default function Hero(){
  return (
    <section style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"}}>
      <h1 style={{color:"#d4af37",fontSize:50}}>WANZE INTERNATIONAL</h1>
      <p>Premium Bath & Wellness Supplier</p>
    </section>
  );
}
