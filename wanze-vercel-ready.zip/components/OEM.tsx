
export default function OEM(){
  return (
    <section style={{padding:40}}>
      <h2 style={{color:"#d4af37"}}>OEM / Private Label</h2>
      <p>Custom branding and manufacturing solutions.</p>
    </section>
  );
}
