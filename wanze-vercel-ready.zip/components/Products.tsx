
export default function Products(){
  return (
    <section style={{padding:40}}>
      <h2 style={{color:"#d4af37"}}>Products</h2>
      <ul>
        <li>Sauna Accessories</li>
        <li>Wooden Products</li>
        <li>Textiles</li>
        <li>Essential Oils</li>
      </ul>
    </section>
  );
}
