
module.exports = {
  reactStrictMode: true
};
